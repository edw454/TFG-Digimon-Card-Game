using System.Collections;
using System.Collections.Generic;
using Fusion;
using UnityEngine;

public struct NetworkInputData : INetworkInput
{
    //public const byte MOUSEBUTTON0 = 1;

    public CardData cardData;

    //public NetworkButtons buttons;

    //public Vector2 direction;
}
