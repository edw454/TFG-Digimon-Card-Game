public enum CardColor
{
	red,
	azul,
	yellow,
	black,
	green,
	white
}